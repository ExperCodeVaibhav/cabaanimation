# CAABAA - Car Customization Website

A pure HTML, CSS, and JavaScript website for car customization and accessory visualization.

## Files Structure

```
public/
├── index.html    - Main HTML file
├── styles.css    - Pure CSS styling (no frameworks)
└── script.js     - Vanilla JavaScript with animations

attached_assets/
└── generated_images/  - Car images and accessories

server.py         - Simple Python HTTP server for development
```

## How to Run

### Option 1: Direct Browser Access
Simply open `public/index.html` in your web browser. Note: Some features may require a local server due to CORS restrictions.

### Option 2: Python HTTP Server (Recommended)
```bash
python3 server.py
```
Then open http://localhost:5000 in your browser.

### Option 3: Any Static Server
You can use any static file server to serve the `public` directory.

## Features

- **Pure HTML/CSS/JavaScript** - No frameworks or build tools required
- **Responsive Design** - Works on desktop and mobile devices
- **Smooth Animations** - Using Anime.js library
- **Modern UI** - Clean, professional design
- **All Sections Included**:
  - Hero section with animated car
  - Parallax showcase
  - Feature cards
  - Video section placeholder
  - Visual gallery
  - Accessory grid with hover effects
  - Community builds showcase
  - Why CAABAA section
  - Motivational CTA
  - Footer with social links

## Technologies Used

- HTML5
- CSS3 (Pure CSS, no preprocessors)
- Vanilla JavaScript (ES6+)
- Anime.js (loaded via CDN for animations)

## Browser Support

Works in all modern browsers (Chrome, Firefox, Safari, Edge).

## License

MIT
