// CAABAA - Vanilla JavaScript functionality

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // ============ HERO SECTION ANIMATIONS ============
    function initHeroAnimations() {
        const heroTitle = document.getElementById('hero-title');
        const heroSubtitle = document.getElementById('hero-subtitle');
        const heroButtons = document.getElementById('hero-buttons');
        const heroCar = document.getElementById('hero-car');
        
        if (!heroTitle || !heroSubtitle || !heroButtons || !heroCar) return;
        
        // Create timeline for hero section
        const timeline = anime.timeline();
        
        timeline
            .add({
                targets: heroTitle,
                opacity: [0, 1],
                translateY: [-30, 0],
                duration: 1000,
                easing: 'easeOutQuad'
            })
            .add({
                targets: heroSubtitle,
                opacity: [0, 1],
                translateY: [-20, 0],
                duration: 800,
                easing: 'easeOutQuad'
            }, '-=600')
            .add({
                targets: heroButtons,
                opacity: [0, 1],
                translateY: [20, 0],
                duration: 800,
                easing: 'easeOutQuad'
            }, '-=400')
            .add({
                targets: heroCar,
                opacity: [0, 1],
                translateY: [60, 0],
                duration: 1200,
                easing: 'easeOutQuad',
                complete: function() {
                    // Add glow animation after initial animation
                    heroCar.classList.add('hero-car-glow');
                }
            }, '-=800');
    }
    
    // ============ PARALLAX SCROLL EFFECT ============
    function initParallaxEffect() {
        const parallaxSection = document.getElementById('parallax');
        const parallaxBg = document.getElementById('parallax-bg');
        const parallaxText = document.getElementById('parallax-text');
        
        if (!parallaxSection || !parallaxBg) return;
        
        let hasAnimated = false;
        
        // Scroll handler for parallax effect
        function handleParallaxScroll() {
            const rect = parallaxSection.getBoundingClientRect();
            const scrollProgress = 1 - (rect.top / window.innerHeight);
            
            // Apply parallax transformation
            const scale = 1 + (scrollProgress * 0.1);
            const opacity = Math.max(0.3, 1 - (scrollProgress * 0.5));
            
            parallaxBg.style.transform = `scale(${scale})`;
            parallaxBg.style.opacity = opacity;
        }
        
        // Intersection observer for text animation
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !hasAnimated && parallaxText) {
                    anime({
                        targets: parallaxText,
                        opacity: [0, 1],
                        scale: [0.9, 1],
                        duration: 1200,
                        easing: 'easeOutQuad'
                    });
                    hasAnimated = true;
                }
            });
        }, { threshold: 0.3 });
        
        observer.observe(parallaxSection);
        window.addEventListener('scroll', handleParallaxScroll);
    }
    
    // ============ FEATURE CARDS ANIMATION ============
    function initFeatureCardsAnimation() {
        const featureCards = document.querySelectorAll('.feature-card');
        if (featureCards.length === 0) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    anime({
                        targets: featureCards,
                        opacity: [0, 1],
                        translateY: [60, 0],
                        delay: anime.stagger(150),
                        duration: 1000,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.1 });
        
        const container = document.getElementById('feature-cards');
        if (container) observer.observe(container);
    }
    
    // ============ VIDEO SECTION ANIMATION ============
    function initVideoSectionAnimation() {
        const videoContainer = document.getElementById('video-container');
        if (!videoContainer) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    anime({
                        targets: videoContainer,
                        opacity: [0, 1],
                        scale: [0.95, 1],
                        duration: 1200,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.2 });
        
        observer.observe(videoContainer);
    }
    
    // ============ GALLERY IMAGES ANIMATION ============
    function initGalleryAnimation() {
        const galleryImages = document.querySelectorAll('.gallery-image');
        if (galleryImages.length === 0) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const images = document.querySelectorAll('.gallery-image');
                    anime({
                        targets: images,
                        opacity: [0, 1],
                        translateY: [80, 0],
                        delay: anime.stagger(200),
                        duration: 1200,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.1 });
        
        const gallery = document.getElementById('gallery');
        if (gallery) observer.observe(gallery);
    }
    
    // ============ ACCESSORY GRID ANIMATION ============
    function initAccessoryGridAnimation() {
        const accessoryItems = document.querySelectorAll('.accessory-item');
        if (accessoryItems.length === 0) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    anime({
                        targets: accessoryItems,
                        opacity: [0, 1],
                        translateX: function(el, i) {
                            return [(i % 2 === 0 ? -60 : 60), 0];
                        },
                        delay: anime.stagger(100),
                        duration: 1000,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.1 });
        
        const grid = document.getElementById('accessory-grid');
        if (grid) observer.observe(grid);
    }
    
    // ============ COMMUNITY BUILDS ANIMATION ============
    function initCommunityBuildsAnimation() {
        const buildCards = document.querySelectorAll('.build-card');
        if (buildCards.length === 0) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    anime({
                        targets: buildCards,
                        opacity: [0, 1],
                        scale: [0.9, 1],
                        delay: anime.stagger(120),
                        duration: 1000,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.1 });
        
        const grid = document.getElementById('community-grid');
        if (grid) observer.observe(grid);
    }
    
    // ============ WHY CAABAA ANIMATION ============
    function initWhyCaabaaAnimation() {
        const valueCards = document.querySelectorAll('.value-card');
        if (valueCards.length === 0) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    anime({
                        targets: valueCards,
                        opacity: [0, 1],
                        translateY: [40, 0],
                        delay: anime.stagger(100),
                        duration: 1000,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.1 });
        
        const grid = document.getElementById('why-grid');
        if (grid) observer.observe(grid);
    }
    
    // ============ MOTIVATIONAL CTA ANIMATION ============
    function initCTAAnimation() {
        const ctaSection = document.getElementById('cta-section');
        const ctaContent = ctaSection ? ctaSection.querySelector('.cta-content') : null;
        
        if (!ctaContent) return;
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    anime({
                        targets: ctaContent,
                        opacity: [0, 1],
                        scale: [0.95, 1],
                        duration: 1200,
                        easing: 'easeOutQuad'
                    });
                    observer.disconnect();
                }
            });
        }, { threshold: 0.3 });
        
        observer.observe(ctaSection);
    }
    
    // ============ INITIALIZE ALL ANIMATIONS ============
    initHeroAnimations();
    initParallaxEffect();
    initFeatureCardsAnimation();
    initVideoSectionAnimation();
    initGalleryAnimation();
    initAccessoryGridAnimation();
    initCommunityBuildsAnimation();
    initWhyCaabaaAnimation();
    initCTAAnimation();
    
    console.log('CAABAA website loaded successfully!');
});
